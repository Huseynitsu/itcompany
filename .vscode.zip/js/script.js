$(document).ready(function () {
    var swiper = new Swiper("#swiperProduct", {
        slidesPerView: 3.2,
        autoplay: true,
        spaceBetween: 30,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
    });

    var swiperHarada = new Swiper('.swiper-container2', {
        slidesPerView: 1,
        spaceBetween: 2,
        loop: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            300: { slidesPerView: 1.5, spaceBetween: 15 },
            768: { slidesPerView: 1.5, spaceBetween: 30 }
        }
    });

    var mainSlider = new Swiper(".main-screen__slider", {
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        autoHeight: true,
        loop: true,
        effect: "fade",
        speed: 800,
        disableOnInteraction: true,
        /*autoplay: {
            delay: 15000,
        },*/
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
            renderBullet: function () {
                return `
                    <span class="swiper-pagination-bullet">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle class="circle-progress" cx="11" cy="11" r="10.5" stroke="black" stroke-width="1"/>
                        </svg>
                    </span>
                `;
            },
        },
    });
    $('.main-screen').find('.swiper-pagination-bullet-active .circle-progress').on("animationend", function () {
        mainSlider.slideNext()
    });
    mainSlider.on('transitionStart', function () {
        $('.main-screen').find('.swiper-pagination-bullet-active .circle-progress').on("animationend", function () {
            mainSlider.slideNext()
        });
    })
});